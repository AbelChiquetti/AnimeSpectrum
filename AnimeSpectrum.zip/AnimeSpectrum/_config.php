<?php 

$websiteTitle = "AnimeZia"; // Website Name
$websiteUrl = "//{$_SERVER['SERVER_NAME']}";  // Website URL
$websiteLogo = "https://cdnzia.pages.dev/images/logo.webp"; // Logo
$websiteLogo2 = "https://cdnzia.pages.dev/images/logo2.webp";
$contactEmail = "senku@animezia.com"; // Contact Email


//Donate 
$donate = "https://api.whatsapp.com/send/?phone=5548984160728";

// Socials 
$telegram = "https://api.whatsapp.com/send/?phone=5548984160728"; // telegram
$discord = "#"; // Discord
$redit = "#"; // Reddit
$twitter = "#"; // Twitter
 


$disqus = "https://watchzia.disqus.com"; // Disqus

$cdn = "https://cdnzia.pages.dev"; // cdn repo https://github.com/warlordsnet/cdnzia

// API URL
$api ="https://animezia.onrender.com"; // api repo https://github.com/warlordsnet/zia-api

$imgk = "ani1"; // your imagekit id

 $iani = "hxxpz:qqapi*c=nzu?ex*=rg";
 $s1 = str_replace("x","t",$iani);
 $s2 = str_replace("z","s",$s1);
 $s3 = str_replace("q","/",$s2);
 $s4 = str_replace("*",".",$s3);
 $s5 = str_replace("?","m",$s4);
 $ani = str_replace("=","o",$s5);

$banner = "https://cdnzia.pages.dev/images/banner.webp";  //Banner
?>
